                                     /*
RB0 -> LDR Sensor, works as Interrupt that Starts the Servo Motor
RC2 -> Servo Motor, Starts whenever the Interrupt "RB0" is Triggered
RB3 -> Water Pump, Sleeps for 599 ms (approximatly 600 ms) and Works for 599 ms (roughly 600 ms)
*/
unsigned int tick=0;
unsigned int tik2=0;
unsigned int angle;
unsigned int Dcntr;
unsigned int Mcntr;
unsigned char cntr;
unsigned char HL;//High Low
unsigned char i;

char temp_read[16];
unsigned char Fcntr;
unsigned int result;
float voltage,temperature;
unsigned int temperature1;
void myDelay(unsigned int);
void CheckServo(void);

void ATD_init(void);
unsigned int ATD_read(void);
void interrupt(void);




//LCD definition
sbit LCD_RS at RD0_bit;
sbit LCD_EN at RD1_bit;
sbit LCD_D4 at RD2_bit;
sbit LCD_D5 at RD3_bit;
sbit LCD_D6 at RD4_bit;
sbit LCD_D7 at RD5_bit;

sbit LCD_RS_Direction at TRISD0_bit;
sbit LCD_EN_Direction at TRISD1_bit;
sbit LCD_D4_Direction at TRISD2_bit;
sbit LCD_D5_Direction at TRISD3_bit;
sbit LCD_D6_Direction at TRISD4_bit;
sbit LCD_D7_Direction at TRISD5_bit;

   void interrupt(void){
   if(INTCON&0x02){//External Interrupt


   INTCON=INTCON&0xFD;
   }
   if(INTCON&0x04)
   {// will get here every 1ms
     TMR0=248;
     Mcntr++;
     Dcntr++;

          if(Dcntr==10000){//after 500 ms
       PORTB = PORTB | 0x08;
     }
     if (Dcntr == 800 ){//after
      PORTB = PORTB & 0xF7;
      Dcntr=0;
     }

    INTCON = INTCON & 0xFB; //clear T0IF
    }
   if(PIR1&0x04){//CCP1 interrupt
     if(HL){ //high
     CCPR1H= angle >>8;
     CCPR1L= angle;
     HL=0;//next time low
     CCP1CON=0x09;//next time Falling edge
     TMR1H=0;
     TMR1L=0;
   }
     else
   {  //low
       CCPR1H= (40000 - angle) >>8;
       CCPR1L= (40000 - angle);
       CCP1CON=0x08; //next time rising edge
       HL=1; //next time High
       TMR1H=0;
       TMR1L=0;

   }
   PIR1=PIR1&0xFB;
 }
 if(PIR1&0x01){//TMR1 ovwerflow
   PIR1=PIR1&0xFE;
 }

}

void main() {

     TRISA = 0x01; //PORTA SET TO OUTPUT
     TRISB = 0xF7; //RB3 output, RB7:4, RB2:0 INPUT
     TRISC = 0x00; //PORTC SET TO OUTPUT
     OPTION_REG = 0x87; // Use Fosc/4 to trigger TMR0, (Fosc=8MHz) TMR0 will increment every 0.5us
     // prescaler = 256 => 0.5 * 256 = 128 uS => it will increment every 128us
     // to overflow every 1ms (1000 uS) we will need to count 8 times (1000/128)
     // 8 counts == 8 * 128us = 1ms (exactly 1.024 ms)
     //=> TMR0 = 256-8 = 248
     TMR0 = 248;
     //INTCON = INTCON | 0xB0; //GIE = 1, INTE = 1, T0IE = 1
     TMR1H=0;
     TMR1L=0;
     HL=1; //start high
     CCP1CON=0x08;//
     T1CON=0x01;//TMR1 On Fosc/4 (inc 0.5uS) with 0 prescaler (TMR1 overflow after 0xFFFF counts ==65535)==> 32.767ms
     INTCON=0xF0;//enable TMR0 overflow, TMR1 overflow, External interrupts and peripheral interrupts;
     PIE1=PIE1|0x04;// Enable CCP1 interrupts
     CCPR1H=2000>>8;
     CCPR1L=2000;
     angle=800; //600us initially == 1000*0.5=500

     while(1)
     {
      //initiate LCD and print welcome screen
      lcd_init();
      lcd_cmd(_lcd_clear);
      lcd_cmd(_LCD_CURSOR_OFF);
      lcd_out(1,1,"Green House");
      myDelay(1000);
      lcd_cmd(_lcd_clear);
      lcd_cmd(_LCD_CURSOR_OFF);
      //initiate ATD and read
      ATD_init();
      ATD_read();
      myDelay(500);
      result=ATD_read();          // Reading ADC values
      voltage=result * 4.88;        // Convert it into the voltage
      temperature =voltage/10.0;    // Getting the temperature values
      IntToStr(temperature,temp_read);// convert from integer to string
      ltrim(temp_read);
      Lcd_Out(1,1,"Temperature = ");
      Lcd_Out(1,15,temp_read);
      myDelay(3000);
      lcd_cmd(_lcd_clear);
      lcd_cmd(_LCD_CURSOR_OFF);
      lcd_out(1,1,"checking light");
      myDelay(500);
      //check light for servo
      CheckServo();
      PORTB = PORTB | 0x80;
      myDelay(500);
      PORTB = PORTB & 0xF7;
      //check light for servo
      for(i = 0; i < 3; i++)
      {
       myDelay(500);
       CheckServo();
      }


     CheckServo();

     ATD_init(); // initialize the ATD module
     cntr=0;
     Mcntr=0;
     TMR0=248;
     OPTION_REG = 0x87;//Fosc/4 with 256 prescaler => incremetn every 0.5us*256=128us = => overflow 8count*128us=1ms to overflow
     INTCON = 0xA0; // GIE, T0IE and INTE (TMR) overflow interrupt and External Interrupt Enable)

     TRISC = 0x01;
     TRISB = 0x01;
     TRISA = 0xff;

       lcd_init();
       PORTB = PORTB | 0x08;
       lcd_cmd(_lcd_clear);
          myDelay(4000);

 }
 }


void myDelay(unsigned int x){
     Mcntr=0;
     while(Mcntr<x);
}


void CheckServo(void)
{
       lcd_out(1,1,"Checking for Light");
 if(!(PORTB & 0X01))
       {
         lcd_cmd(_LCD_CURSOR_OFF);
         lcd_cmd(_lcd_clear);
         angle = 2800;
         lcd_out(1,1,"Roof is Openned");
         //delay_ms(1000);
         myDelay(1000);
       }
      else
      {
         lcd_cmd(_LCD_CURSOR_OFF);
         lcd_cmd(_lcd_clear);
                                   angle = 800;
         lcd_out(1,1,"Roof is Closed");
         //delay_ms(1000);
         myDelay(1000);

      }
}         void ATD_init(void){
ADCON0=0x41;//ON, Channel 0, Fosc/16== 500KHz, Dont Go
ADCON1=0xCE;// RA0 Analog, others are Digital, Right Allignment,
TRISA=0x01;
}


 unsigned int ATD_read(void){
         ADCON0=ADCON0 | 0x04;//GO
         while(ADCON0&0x04);//wait until DONE
         return (ADRESH<<8)|ADRESL;
}